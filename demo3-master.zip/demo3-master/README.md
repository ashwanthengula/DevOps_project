Hello World! (WAR-style)
===============

This is the simplest possible Java webapp for testing servlet container deployments with maven project with trigger.  It should work on any container and requires no other dependencies or configuration.
This is modified file.this is modified.
I am modifying the code
I am Modifying.
